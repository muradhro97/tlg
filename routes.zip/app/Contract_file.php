<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contract_file extends Model
{
    protected $table = 'contract_files';

    protected $guarded = ['id'];
}
