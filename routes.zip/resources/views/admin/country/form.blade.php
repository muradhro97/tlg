@include('partials.validation-errors')



{!! Field::text('name' , trans('main.name') ) !!}
{!! Field::text('nationality' , trans('main.nationality') ) !!}






