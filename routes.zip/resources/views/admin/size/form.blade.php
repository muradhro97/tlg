@include('partials.validation-errors')



{!! Field::text('size' , trans('main.size') ) !!}








