{{--@include('partials.validation-errors')--}}






{!! Field::text('name' , 'الاسم') !!}
{!! Field::text('phone' , 'التليفون') !!}
{!! Field::password('password' , 'كلمه السر') !!}
{!! Field::password('password_confirmation' , 'تاكيد كلمه السر') !!}


