@include('partials.validation-errors')


{!! Field::text('name' , 'الاسم') !!}




