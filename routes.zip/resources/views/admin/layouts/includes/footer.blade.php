<div class="footer">

    <div>
{{--        <strong>Copyright</strong> {{$website_name}} &copy; {{date('Y')}}--}}
    </div>
</div>
