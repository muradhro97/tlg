@include('partials.validation-errors')



{!! Field::text('name' , trans('main.name') ) !!}

{!! Field::text('job' , trans('main.job') ) !!}

{!! Field::text('phone_number' , trans('main.phone_number') ) !!}

{!! Field::text('address' , trans('main.address') ) !!}

{!! Field::textarea('details' , trans('main.details') ) !!}







