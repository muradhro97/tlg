@include('partials.validation-errors')



{!! Field::text('color' , trans('main.color') ) !!}








